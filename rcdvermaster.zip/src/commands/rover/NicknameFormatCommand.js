const Command = require('../Command')

module.exports =
class NicknameFormatCommand extends Command {
  constructor (client) {
    super(client, {
      name: 'nicknameformat',
      properName: 'NicknameFormat',
      aliases: ['rcdvernicknameformat'],
      description: "`<format>` Set the format RCDVer will use when setting users' nicknames. Available replacements are %USERNAME%, %RANK%, %USERID%, %SERVER%, %DISCORDNAME%, and %DISCORDID%. Example:` %USERNAME% - (%USERID%)`. Default `%USERNAME%`.",

      args: [
        {
          key: 'format',
          label: 'format',
          prompt: 'Nickname format',
          type: 'string',
          infinite: false,
          default: false
        }
      ]
    })
  }

  async fn (msg, args) {
    if (args.format) {
      this.server.setSetting('nicknameFormat', args.format)
      msg.reply(`Set nickname format to \`${args.format}\``)
    } else {
      this.server.setSetting('nicknameFormat', undefined)
      msg.reply('Nickname format set back to default')
    }
  }
}
